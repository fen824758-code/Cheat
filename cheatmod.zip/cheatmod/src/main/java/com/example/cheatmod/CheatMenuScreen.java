package com.example.cheatmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Меню чита (клавиша X): тёмная панель с фиолетовой рамкой и переключателями. */
public final class CheatMenuScreen extends Screen {
    private static final int PANEL_X = 10;
    private static final int PANEL_Y = 10;
    private static final int PANEL_W = 150;
    private static final int PAD = 6;
    private static final int ROW_H = 24;
    private static final int GAP = 4;

    private static final int PURPLE = 0xFF7B1FFF;
    private static final int PANEL_BG = 0xF0101016;
    private static final int ROW_BG = 0xFF17171F;
    private static final int ROW_BG_HOVER = 0xFF202030;
    private static final int OFF_BG = 0xFF3A3A48;
    private static final int TEXT = 0xFFE8E8F0;

    private static final String[] CROSSHAIR = {
            "....#....",
            "..#####..",
            ".#..#..#.",
            ".#.....#.",
            "###.#.###",
            ".#.....#.",
            ".#..#..#.",
            "..#####..",
            "....#...."};
    private static final String[] TOTEM = {
            "...###...",
            "..#####..",
            "..#.#.#..",
            "..#####..",
            ".#######.",
            "#.#####.#",
            "..#####..",
            "..##.##..",
            "..##.##.."};
    private static final String[] EYE = {
            ".........",
            "...###...",
            ".##...##.",
            "#..###..#",
            "#..#.#..#",
            "#..###..#",
            ".##...##.",
            "...###...",
            "........."};

    private record Row(String label, String[] icon, BooleanSupplier get, Consumer<Boolean> set) {}

    private final List<Row> rows = List.of(
            new Row("ESP", CROSSHAIR, () -> Config.espEnabled, v -> Config.espEnabled = v),
            new Row("KILL AURA", CROSSHAIR, () -> Config.auraEnabled, v -> Config.auraEnabled = v),
            new Row("AUTO TOTEM", TOTEM, () -> Config.totemEnabled, v -> Config.totemEnabled = v),
            new Row("Night vision", EYE, () -> Config.nightVisionEnabled, v -> Config.nightVisionEnabled = v));

    public CheatMenuScreen() {
        super(Text.literal("CheatMod"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int panelHeight() {
        return PAD * 2 + rows.size() * ROW_H + (rows.size() - 1) * GAP;
    }

    private int rowY(int i) {
        return PANEL_Y + PAD + i * (ROW_H + GAP);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Затемнение экрана
        ctx.fill(0, 0, this.width, this.height, 0x88000000);

        int x = PANEL_X, y = PANEL_Y, w = PANEL_W, h = panelHeight();

        // Фиолетовое свечение вокруг панели
        for (int i = 10; i >= 1; i--) {
            int alpha = 3 + (10 - i) * 2;
            ctx.fill(x - i, y - i, x + w + i, y + h + i, (alpha << 24) | 0x7B1FFF);
        }

        // Рамка со срезанными углами
        ctx.fill(x, y, x + w, y + h, PURPLE);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, PANEL_BG);
        int c = 4;
        for (int i = 0; i < c; i++) {
            int len = c - i;
            // срез углов: закрашиваем угловые пиксели фоном экрана
            ctx.fill(x, y + i, x + len, y + i + 1, 0xFF0B0B10);
            ctx.fill(x + w - len, y + i, x + w, y + i + 1, 0xFF0B0B10);
            ctx.fill(x, y + h - i - 1, x + len, y + h - i, 0xFF0B0B10);
            ctx.fill(x + w - len, y + h - i - 1, x + w, y + h - i, 0xFF0B0B10);
        }
        // диагональные грани углов
        for (int i = 0; i < c; i++) {
            int d = c - 1 - i;
            ctx.fill(x + d, y + i, x + d + 1, y + i + 1, PURPLE);
            ctx.fill(x + w - d - 1, y + i, x + w - d, y + i + 1, PURPLE);
            ctx.fill(x + d, y + h - i - 1, x + d + 1, y + h - i, PURPLE);
            ctx.fill(x + w - d - 1, y + h - i - 1, x + w - d, y + h - i, PURPLE);
        }

        // Строки
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int ry = rowY(i);
            int rx = x + PAD;
            int rw = w - PAD * 2;
            boolean hover = inRow(mouseX, mouseY, i);
            ctx.fill(rx, ry, rx + rw, ry + ROW_H, hover ? ROW_BG_HOVER : ROW_BG);

            boolean on = row.get.getAsBoolean();
            drawIcon(ctx, row.icon, rx + 6, ry + (ROW_H - 18) / 2, on ? PURPLE : 0xFF6A6A7A);
            ctx.drawText(this.textRenderer, row.label, rx + 30, ry + (ROW_H - 8) / 2, TEXT, false);
            drawToggle(ctx, rx + rw - 32, ry + (ROW_H - 14) / 2, on);
        }
    }

    private void drawIcon(DrawContext ctx, String[] bmp, int x, int y, int color) {
        for (int r = 0; r < bmp.length; r++) {
            for (int col = 0; col < bmp[r].length(); col++) {
                if (bmp[r].charAt(col) == '#') {
                    ctx.fill(x + col * 2, y + r * 2, x + col * 2 + 2, y + r * 2 + 2, color);
                }
            }
        }
    }

    private void drawToggle(DrawContext ctx, int x, int y, boolean on) {
        int w = 28, h = 14;
        int bg = on ? PURPLE : OFF_BG;
        pill(ctx, x, y, w, h, bg);
        int k = 10;
        int kx = on ? x + w - k - 2 : x + 2;
        pill(ctx, kx, y + 2, k, k, 0xFFF4F4FA);
    }

    /** Скруглённый прямоугольник из двух перекрывающихся прямоугольников. */
    private void pill(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x + 2, y, x + w - 2, y + h, color);
        ctx.fill(x, y + 2, x + w, y + h - 2, color);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, color);
    }

    private boolean inRow(double mx, double my, int i) {
        int rx = PANEL_X + PAD;
        int rw = PANEL_W - PAD * 2;
        int ry = rowY(i);
        return mx >= rx && mx < rx + rw && my >= ry && my < ry + ROW_H;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (int i = 0; i < rows.size(); i++) {
                if (inRow(mouseX, mouseY, i)) {
                    Row row = rows.get(i);
                    row.set.accept(!row.get.getAsBoolean());
                    Config.save();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Повторное нажатие кнопки меню закрывает его
        if (CheatMod.menuKey != null && CheatMod.menuKey.matchesKey(keyCode, scanCode)) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
