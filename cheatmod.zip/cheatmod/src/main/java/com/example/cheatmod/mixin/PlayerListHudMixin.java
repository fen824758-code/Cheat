package com.example.cheatmod.mixin;

import com.example.cheatmod.Config;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Добавляет тег друга перед ником в табе. */
@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {
    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void cheatmod$friendTag(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        String tag = Config.tagOf(entry.getProfile().getName());
        if (tag == null || tag.isEmpty()) return;
        cir.setReturnValue(Text.literal("[" + tag + "] ").formatted(Formatting.GREEN).append(cir.getReturnValue()));
    }
}
