package com.example.cheatmod;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * AutoCrystal: рядом с ближайшим игроком сам ставит кристаллы на обсидиан/бедрок и сам их разбивает.
 * Не ставит и не бьёт кристаллы ближе crystalMinSelf к тебе и выключается при низком здоровье.
 */
public final class AutoCrystal {
    private static final double TARGET_RANGE = 10.0;   // искать игрока в этом радиусе
    private static final double MAX_TARGET_DIST = 9.0; // дальше от цели кристалл почти не бьёт

    private static int placeCd = 0;
    private static int breakCd = 0;
    private static int idle = 0;
    private static int prevSlot = -1;

    private AutoCrystal() {}

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            placeCd = breakCd = idle = 0;
            prevSlot = -1;
            return;
        }
        if (placeCd > 0) placeCd--;
        if (breakCd > 0) breakCd--;

        if (!Config.crystalEnabled || !p.isAlive() || p.isSpectator() || mc.currentScreen != null) {
            restoreSlot(p);
            return;
        }
        // Защита: при низком здоровье не взрываем ничего рядом
        if (p.getHealth() + p.getAbsorptionAmount() <= Config.crystalMinHealth) return;

        PlayerEntity target = findTarget(mc, p);
        if (target == null) {
            if (++idle > 10) restoreSlot(p);
            return;
        }
        idle = 0;

        // 1) Разбиваем кристалл
        if (breakCd == 0) {
            EndCrystalEntity crystal = findCrystalToBreak(mc, p, target);
            if (crystal != null) {
                aimAt(p, crystal.getBoundingBox().getCenter());
                mc.interactionManager.attackEntity(p, crystal);
                p.swingHand(Hand.MAIN_HAND);
                breakCd = ticks(Config.crystalBreakDelay);
                return;
            }
        }

        // 2) Ставим кристалл
        if (placeCd == 0) {
            BlockPos pos = findPlacement(mc, p, target);
            if (pos != null) {
                Hand hand = prepareHand(p);
                if (hand != null) {
                    Vec3d top = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                    aimAt(p, top);
                    BlockHitResult hit = new BlockHitResult(top, Direction.UP, pos, false);
                    mc.interactionManager.interactBlock(p, hand, hit);
                    p.swingHand(hand);
                    placeCd = ticks(Config.crystalPlaceDelay);
                }
            }
        }
    }

    private static int ticks(double seconds) {
        return Math.max(1, (int) Math.round(seconds * 20.0));
    }

    private static void restoreSlot(ClientPlayerEntity p) {
        if (prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }
    }

    /** Возвращает руку с кристаллом: левая, если там кристалл, иначе берёт кристалл из хотбара. */
    private static Hand prepareHand(ClientPlayerEntity p) {
        if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) return Hand.OFF_HAND;
        if (p.getMainHandStack().isOf(Items.END_CRYSTAL)) return Hand.MAIN_HAND;
        if (!Config.crystalSwitch) return null;

        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) {
                if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
                p.getInventory().selectedSlot = i;
                return Hand.MAIN_HAND;
            }
        }
        return null;
    }

    private static PlayerEntity findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        PlayerEntity best = null;
        double bestDist = TARGET_RANGE;
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == p || !other.isAlive() || other.isSpectator()) continue;
            double d = p.distanceTo(other);
            if (d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    private static EndCrystalEntity findCrystalToBreak(MinecraftClient mc, ClientPlayerEntity p, PlayerEntity target) {
        double range = Config.crystalRange;
        Vec3d eye = p.getEyePos();
        List<EndCrystalEntity> list = mc.world.getEntitiesByClass(
                EndCrystalEntity.class, new Box(p.getBlockPos()).expand(range + 1.0), e -> e.isAlive());

        EndCrystalEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (EndCrystalEntity c : list) {
            Vec3d center = c.getBoundingBox().getCenter();
            if (eye.distanceTo(center) > range) continue;
            if (p.getPos().distanceTo(c.getPos()) < Config.crystalMinSelf) continue;
            double td = target.getPos().distanceTo(c.getPos());
            if (td > MAX_TARGET_DIST) continue;
            if (td < bestDist) {
                bestDist = td;
                best = c;
            }
        }
        return best;
    }

    /** Лучший блок (обсидиан/бедрок) для кристалла: ближе к цели и дальше от тебя. */
    private static BlockPos findPlacement(MinecraftClient mc, ClientPlayerEntity p, PlayerEntity target) {
        double range = Config.crystalRange;
        int r = (int) Math.ceil(range);
        Vec3d eye = p.getEyePos();
        BlockPos base = BlockPos.ofFloored(eye);

        BlockPos best = null;
        double bestScore = -1e9;

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    BlockState st = mc.world.getBlockState(pos);
                    if (!(st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.BEDROCK))) continue;

                    Vec3d cp = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                    if (eye.distanceTo(cp) > range) continue;

                    double sd = p.getPos().distanceTo(cp);
                    if (sd < Config.crystalMinSelf) continue;

                    double td = target.getPos().distanceTo(cp);
                    if (td > MAX_TARGET_DIST) continue;

                    if (!mc.world.getBlockState(pos.up()).isAir()
                            || !mc.world.getBlockState(pos.up(2)).isAir()) continue;

                    double score = (1.0 - td / 12.0) - 0.6 * Math.max(0.0, 1.0 - sd / 12.0);
                    if (score <= bestScore) continue;

                    Box box = new Box(pos.getX(), pos.getY() + 1, pos.getZ(),
                            pos.getX() + 1, pos.getY() + 3, pos.getZ() + 1);
                    if (!mc.world.getOtherEntities(null, box).isEmpty()) continue;

                    bestScore = score;
                    best = pos;
                }
            }
        }
        return best;
    }

    private static void aimAt(ClientPlayerEntity p, Vec3d point) {
        Vec3d eye = p.getEyePos();
        double dx = point.x - eye.x;
        double dy = point.y - eye.y;
        double dz = point.z - eye.z;

        float wantYaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float wantPitch = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);

        p.setYaw(p.getYaw() + step(MathHelper.wrapDegrees(wantYaw - p.getYaw())));
        p.setPitch(MathHelper.clamp(p.getPitch() + step(wantPitch - p.getPitch()), -90.0f, 90.0f));
    }

    private static float step(float d) {
        float ad = Math.abs(d);
        if (ad <= 1.0f) return d;
        float s = Math.min(Math.min(Math.max(8.0f, ad * 0.7f), 45.0f), ad);
        return Math.copySign(s, d);
    }
}
