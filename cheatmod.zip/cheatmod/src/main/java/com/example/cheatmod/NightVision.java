package com.example.cheatmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Ночное зрение: клиентский эффект, сервер о нём не знает. */
public final class NightVision {
    /** Наш эффект отличаем от настоящего (зелье/маяк) по огромной длительности. */
    private static final int OUR_DURATION = 1_000_000;
    private static final int OUR_THRESHOLD = 500_000;

    private NightVision() {}

    private static boolean isOurs(StatusEffectInstance e) {
        return e != null && e.getDuration() > OUR_THRESHOLD;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (Config.nightVisionEnabled) {
            if (cur == null) {
                p.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, OUR_DURATION, 0, false, false, false));
            }
        } else if (isOurs(cur)) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION); // настоящий эффект не трогаем
        }
    }
}
