package com.example.cheatmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Ночное зрение: клиентский эффект, сервер о нём не знает. */
public final class NightVision {
    private static boolean applied = false;

    private NightVision() {}

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            applied = false;
            return;
        }

        if (Config.nightVisionEnabled) {
            // Не трогаем настоящий эффект (зелье/маяк), добавляем свой только если его нет
            if (p.getStatusEffect(StatusEffects.NIGHT_VISION) == null) {
                p.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                applied = true;
            }
        } else if (applied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            applied = false;
        }
    }
}
