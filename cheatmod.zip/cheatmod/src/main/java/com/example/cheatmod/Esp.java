package com.example.cheatmod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/** ESP: игроки, сундуки, бочки — подсветка сквозь стены. */
public final class Esp {
    private record Target(Box box, float r, float g, float b) {}

    private static final float[] PLAYER = {1.0f, 0.15f, 0.15f};
    private static final float[] CHEST = {1.0f, 0.75f, 0.1f};
    private static final float[] ENDER = {0.7f, 0.2f, 1.0f};
    private static final float[] BARREL = {0.6f, 0.4f, 0.2f};

    private static List<Target> blocks = List.of();
    private static boolean scanned = false;
    private static int counter = 0;

    private Esp() {}

    /** Раз в секунду пересканируем загруженные чанки на сундуки/бочки. */
    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null
                || !Config.espEnabled || !(Config.espChests || Config.espBarrels)) {
            blocks = List.of();
            scanned = false;
            return;
        }
        if (scanned && ++counter % 20 != 0) return;
        scanned = true;

        Vec3d pp = mc.player.getPos();
        int r = Config.espRadius;
        double r2 = (double) r * r;
        // Клиент знает только про загруженные чанки (ограничено дальностью прорисовки)
        int chunkR = Math.min((r >> 4) + 1, mc.options.getClampedViewDistance() + 1);
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;

        List<Target> out = new ArrayList<>();
        for (int cx = pcx - chunkR; cx <= pcx + chunkR; cx++) {
            for (int cz = pcz - chunkR; cz <= pcz + chunkR; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    float[] c = colorFor(be);
                    if (c == null) continue;
                    BlockPos bp = be.getPos();
                    double dx = bp.getX() + 0.5 - pp.x;
                    double dy = bp.getY() + 0.5 - pp.y;
                    double dz = bp.getZ() + 0.5 - pp.z;
                    if (dx * dx + dy * dy + dz * dz > r2) continue;
                    out.add(new Target(new Box(bp).expand(0.002), c[0], c[1], c[2]));
                }
            }
        }
        blocks = out;
    }

    private static float[] colorFor(BlockEntity be) {
        if (be instanceof BarrelBlockEntity) return Config.espBarrels ? BARREL : null;
        if (be instanceof EnderChestBlockEntity) return Config.espChests ? ENDER : null;
        if (be instanceof ChestBlockEntity) return Config.espChests ? CHEST : null; // включая trapped chest
        return null;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.espEnabled || mc.world == null || mc.player == null) return;

        MatrixStack matrices = ctx.matrixStack();
        if (matrices == null) return;

        float td = ctx.tickCounter().getTickDelta(false);
        Vec3d cam = ctx.camera().getPos();

        List<Target> all = new ArrayList<>(blocks);

        if (Config.espPlayers) {
            double r2 = (double) Config.espRadius * Config.espRadius;
            for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player || p.isSpectator()) continue;
                if (p.squaredDistanceTo(mc.player) > r2) continue;
                Vec3d lp = p.getLerpedPos(td);
                Box b = p.getBoundingBox().offset(lp.x - p.getX(), lp.y - p.getY(), lp.z - p.getZ());
                all.add(new Target(b, PLAYER[0], PLAYER[1], PLAYER[2]));
            }
        }
        if (all.isEmpty()) return;

        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = matrices.peek().getPositionMatrix();

        RenderSystem.disableDepthTest(); // сквозь стены
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        // Полупрозрачная заливка
        BufferBuilder fill = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (Target t : all) fillBox(fill, m, t.box, t.r, t.g, t.b, 0.22f);
        BufferRenderer.drawWithGlobalProgram(fill.end());

        // Контур
        RenderSystem.lineWidth(2.0f);
        BufferBuilder lines = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (Target t : all) edges(lines, m, t.box, t.r, t.g, t.b, 1.0f);
        BufferRenderer.drawWithGlobalProgram(lines.end());

        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        matrices.pop();
    }

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, float z, float r, float g, float bl, float a) {
        b.vertex(m, x, y, z).color(r, g, bl, a);
    }

    private static void fillBox(BufferBuilder b, Matrix4f m, Box bx, float r, float g, float bl, float a) {
        float x1 = (float) bx.minX, y1 = (float) bx.minY, z1 = (float) bx.minZ;
        float x2 = (float) bx.maxX, y2 = (float) bx.maxY, z2 = (float) bx.maxZ;
        // низ
        v(b, m, x1, y1, z1, r, g, bl, a); v(b, m, x2, y1, z1, r, g, bl, a);
        v(b, m, x2, y1, z2, r, g, bl, a); v(b, m, x1, y1, z2, r, g, bl, a);
        // верх
        v(b, m, x1, y2, z1, r, g, bl, a); v(b, m, x1, y2, z2, r, g, bl, a);
        v(b, m, x2, y2, z2, r, g, bl, a); v(b, m, x2, y2, z1, r, g, bl, a);
        // север (z1)
        v(b, m, x1, y1, z1, r, g, bl, a); v(b, m, x1, y2, z1, r, g, bl, a);
        v(b, m, x2, y2, z1, r, g, bl, a); v(b, m, x2, y1, z1, r, g, bl, a);
        // юг (z2)
        v(b, m, x1, y1, z2, r, g, bl, a); v(b, m, x2, y1, z2, r, g, bl, a);
        v(b, m, x2, y2, z2, r, g, bl, a); v(b, m, x1, y2, z2, r, g, bl, a);
        // запад (x1)
        v(b, m, x1, y1, z1, r, g, bl, a); v(b, m, x1, y1, z2, r, g, bl, a);
        v(b, m, x1, y2, z2, r, g, bl, a); v(b, m, x1, y2, z1, r, g, bl, a);
        // восток (x2)
        v(b, m, x2, y1, z1, r, g, bl, a); v(b, m, x2, y2, z1, r, g, bl, a);
        v(b, m, x2, y2, z2, r, g, bl, a); v(b, m, x2, y1, z2, r, g, bl, a);
    }

    private static void line(BufferBuilder b, Matrix4f m, float x1, float y1, float z1,
                             float x2, float y2, float z2, float r, float g, float bl, float a) {
        v(b, m, x1, y1, z1, r, g, bl, a);
        v(b, m, x2, y2, z2, r, g, bl, a);
    }

    private static void edges(BufferBuilder b, Matrix4f m, Box bx, float r, float g, float bl, float a) {
        float x1 = (float) bx.minX, y1 = (float) bx.minY, z1 = (float) bx.minZ;
        float x2 = (float) bx.maxX, y2 = (float) bx.maxY, z2 = (float) bx.maxZ;
        // низ
        line(b, m, x1, y1, z1, x2, y1, z1, r, g, bl, a);
        line(b, m, x2, y1, z1, x2, y1, z2, r, g, bl, a);
        line(b, m, x2, y1, z2, x1, y1, z2, r, g, bl, a);
        line(b, m, x1, y1, z2, x1, y1, z1, r, g, bl, a);
        // верх
        line(b, m, x1, y2, z1, x2, y2, z1, r, g, bl, a);
        line(b, m, x2, y2, z1, x2, y2, z2, r, g, bl, a);
        line(b, m, x2, y2, z2, x1, y2, z2, r, g, bl, a);
        line(b, m, x1, y2, z2, x1, y2, z1, r, g, bl, a);
        // стойки
        line(b, m, x1, y1, z1, x1, y2, z1, r, g, bl, a);
        line(b, m, x2, y1, z1, x2, y2, z1, r, g, bl, a);
        line(b, m, x2, y1, z2, x2, y2, z2, r, g, bl, a);
        line(b, m, x1, y1, z2, x1, y2, z2, r, g, bl, a);
    }
}
