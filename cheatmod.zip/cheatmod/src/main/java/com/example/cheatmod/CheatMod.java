package com.example.cheatmod;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class CheatMod implements ClientModInitializer {
    private static final String CATEGORY = "category.cheatmod";
    private static KeyBinding auraKey;
    private static KeyBinding espKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        auraKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.cheatmod.aura", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY));
        espKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.cheatmod.esp", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (auraKey.wasPressed()) {
                Config.auraEnabled = !Config.auraEnabled;
                Config.save();
                toast(mc, "KillAura: " + (Config.auraEnabled ? "ON" : "OFF"));
            }
            while (espKey.wasPressed()) {
                Config.espEnabled = !Config.espEnabled;
                Config.save();
                toast(mc, "ESP: " + (Config.espEnabled ? "ON" : "OFF"));
            }
            KillAura.tick(mc);
            Esp.tick(mc);
        });

        WorldRenderEvents.LAST.register(Esp::render);

        registerCommands();
    }

    private static void toast(MinecraftClient mc, String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(msg), true);
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> boolOption(String name, Consumer<Boolean> setter) {
        return literal(name).then(argument("value", BoolArgumentType.bool()).executes(c -> {
            boolean v = BoolArgumentType.getBool(c, "value");
            setter.accept(v);
            Config.save();
            c.getSource().sendFeedback(Text.literal(name + " = " + v));
            return 1;
        }));
    }

    private static void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(literal("cheat")
                        .then(literal("status").executes(c -> {
                            c.getSource().sendFeedback(Text.literal(
                                    "KillAura: " + Config.auraEnabled + " (range " + Config.auraRange
                                            + ", players " + Config.auraPlayers + ", mobs " + Config.auraMobs + ")"));
                            c.getSource().sendFeedback(Text.literal(
                                    "ESP: " + Config.espEnabled + " (radius " + Config.espRadius
                                            + ", players " + Config.espPlayers + ", chests " + Config.espChests
                                            + ", barrels " + Config.espBarrels + ")"));
                            return 1;
                        }))
                        .then(literal("aura_range").then(argument("value", DoubleArgumentType.doubleArg(1.0, 6.0))
                                .executes(c -> {
                                    Config.auraRange = DoubleArgumentType.getDouble(c, "value");
                                    Config.save();
                                    c.getSource().sendFeedback(Text.literal("aura_range = " + Config.auraRange));
                                    return 1;
                                })))
                        .then(literal("esp_radius").then(argument("value", IntegerArgumentType.integer(16, 500))
                                .executes(c -> {
                                    Config.espRadius = IntegerArgumentType.getInteger(c, "value");
                                    Config.save();
                                    c.getSource().sendFeedback(Text.literal("esp_radius = " + Config.espRadius));
                                    return 1;
                                })))
                        .then(boolOption("aura_players", v -> Config.auraPlayers = v))
                        .then(boolOption("aura_mobs", v -> Config.auraMobs = v))
                        .then(boolOption("esp_players", v -> Config.espPlayers = v))
                        .then(boolOption("esp_chests", v -> Config.espChests = v))
                        .then(boolOption("esp_barrels", v -> Config.espBarrels = v))
                ));
    }
}
