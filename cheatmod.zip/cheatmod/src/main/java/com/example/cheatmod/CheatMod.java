package com.example.cheatmod;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class CheatMod implements ClientModInitializer {
    private static final String CATEGORY = "category.cheatmod";

    /** Клавиша + как переключать и читать флаг. */
    private record Toggle(KeyBinding key, String label, Consumer<Boolean> setter, BooleanSupplier getter) {}

    private static Toggle[] toggles;
    private static KeyBinding friendsKey;

    private static KeyBinding bind(String id, int glfwKey) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(id, InputUtil.Type.KEYSYM, glfwKey, CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        Config.load();

        friendsKey = bind("key.cheatmod.friends", GLFW.GLFW_KEY_Z);

        toggles = new Toggle[]{
                new Toggle(bind("key.cheatmod.aura", GLFW.GLFW_KEY_R), "KillAura",
                        v -> Config.auraEnabled = v, () -> Config.auraEnabled),
                new Toggle(bind("key.cheatmod.esp", GLFW.GLFW_KEY_G), "ESP",
                        v -> Config.espEnabled = v, () -> Config.espEnabled),
                new Toggle(bind("key.cheatmod.totem", GLFW.GLFW_KEY_V), "AutoTotem",
                        v -> Config.totemEnabled = v, () -> Config.totemEnabled),
                new Toggle(bind("key.cheatmod.night", GLFW.GLFW_KEY_N), "NightVision",
                        v -> Config.nightVisionEnabled = v, () -> Config.nightVisionEnabled),
                new Toggle(bind("key.cheatmod.wings", GLFW.GLFW_KEY_X), "Wings",
                        v -> Config.wingsEnabled = v, () -> Config.wingsEnabled),
        };

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (friendsKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new FriendsScreen());
            }
            for (Toggle t : toggles) {
                while (t.key.wasPressed()) {
                    boolean now = !t.getter.getAsBoolean();
                    t.setter.accept(now);
                    Config.save();
                    toast(mc, t.label + ": " + (now ? "ON" : "OFF"));
                }
            }
            KillAura.tick(mc);
            AutoTotem.tick(mc);
            NightVision.tick(mc);
            Wings.tick(mc);
            Esp.tick(mc);
        });

        WorldRenderEvents.LAST.register(Esp::render);
        WorldRenderEvents.LAST.register(Wings::render);

        registerCommands();
    }

    private static void toast(MinecraftClient mc, String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(msg), true);
    }

    // ---------- хелперы команд ----------

    private static LiteralArgumentBuilder<FabricClientCommandSource> boolOption(String name, Consumer<Boolean> setter) {
        return literal(name).then(argument("value", BoolArgumentType.bool()).executes(c -> {
            boolean v = BoolArgumentType.getBool(c, "value");
            setter.accept(v);
            Config.save();
            c.getSource().sendFeedback(Text.literal(name + " = " + v));
            return 1;
        }));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> doubleOption(
            String name, double min, double max, DoubleConsumer setter) {
        return literal(name).then(argument("value", DoubleArgumentType.doubleArg(min, max)).executes(c -> {
            double v = DoubleArgumentType.getDouble(c, "value");
            setter.accept(v);
            Config.save();
            c.getSource().sendFeedback(Text.literal(name + " = " + v));
            return 1;
        }));
    }

    private static int friendAdd(CommandContext<FabricClientCommandSource> c, String tag) {
        String nick = StringArgumentType.getString(c, "nick");
        Config.addFriend(nick, tag);
        String t = Config.tagOf(nick);
        c.getSource().sendFeedback(Text.literal("Друг: " + Config.norm(nick)
                + (t == null || t.isEmpty() ? "" : " [" + t + "]")));
        return 1;
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> friendCommands() {
        return literal("friend")
                .then(literal("add").then(argument("nick", StringArgumentType.word())
                        .executes(c -> friendAdd(c, ""))
                        .then(argument("tag", StringArgumentType.word())
                                .executes(c -> friendAdd(c, StringArgumentType.getString(c, "tag"))))))
                .then(literal("remove").then(argument("nick", StringArgumentType.word()).executes(c -> {
                    String n = StringArgumentType.getString(c, "nick");
                    boolean ok = Config.removeFriend(n);
                    c.getSource().sendFeedback(Text.literal(ok ? "Удалён: " + n : "Такого друга нет: " + n));
                    return 1;
                })))
                .then(literal("list").executes(c -> {
                    StringBuilder sb = new StringBuilder();
                    Config.friends.forEach((n, t) -> sb.append(sb.length() > 0 ? ", " : "")
                            .append(n).append(t.isEmpty() ? "" : " [" + t + "]"));
                    c.getSource().sendFeedback(Text.literal("Друзья: " + (sb.length() == 0 ? "—" : sb)));
                    return 1;
                }));
    }

    private static int status(FabricClientCommandSource s) {
        s.sendFeedback(Text.literal("KillAura: " + Config.auraEnabled + " (range " + Config.auraRange
                + ", players " + Config.auraPlayers + ", mobs " + Config.auraMobs
                + ", walls " + Config.auraWalls + ", cooldown " + Config.auraCooldown
                + ", min interval " + Config.auraAttackInterval + "s"
                + ", aim " + Config.auraAim + " every " + Config.auraAimInterval
                + "s speed " + Config.auraAimSpeed + ", friends " + Config.friends.size() + ")"));
        s.sendFeedback(Text.literal("ESP: " + Config.espEnabled + " (radius " + Config.espRadius
                + ", players " + Config.espPlayers + ", chests " + Config.espChests
                + ", barrels " + Config.espBarrels + ", shulkers " + Config.espShulkers + ")"));
        s.sendFeedback(Text.literal("AutoTotem: " + Config.totemEnabled + " (delay " + Config.totemDelay + "s)"));
        s.sendFeedback(Text.literal("NightVision: " + Config.nightVisionEnabled));
        s.sendFeedback(Text.literal("Wings: " + Config.wingsEnabled + " (scale " + Config.wingsScale
                + ", circle " + Config.wingsCircle + ", particles " + Config.wingsParticles + ")"));
        return 1;
    }

    private static void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(literal("cheat")
                        .then(literal("status").executes(c -> status(c.getSource())))
                        // KillAura
                        .then(doubleOption("aura_range", 1.0, Config.MAX_AURA_RANGE, v -> Config.auraRange = v))
                        .then(doubleOption("aura_interval", 0.1, 5.0, v -> Config.auraAttackInterval = v))
                        .then(doubleOption("aim_interval", 0.2, 10.0, v -> Config.auraAimInterval = v))
                        .then(doubleOption("aim_speed", 0.1, 1.0, v -> Config.auraAimSpeed = v))
                        .then(boolOption("aim", v -> Config.auraAim = v))
                        .then(boolOption("aura_players", v -> Config.auraPlayers = v))
                        .then(boolOption("aura_mobs", v -> Config.auraMobs = v))
                        .then(boolOption("aura_walls", v -> Config.auraWalls = v))
                        .then(boolOption("aura_cooldown", v -> Config.auraCooldown = v))
                        .then(friendCommands())
                        // AutoTotem / NightVision / Wings
                        .then(boolOption("totem", v -> Config.totemEnabled = v))
                        .then(doubleOption("totem_delay", 0.0, 5.0, v -> Config.totemDelay = v))
                        .then(boolOption("nightvision", v -> Config.nightVisionEnabled = v))
                        .then(boolOption("wings", v -> Config.wingsEnabled = v))
                        .then(boolOption("wing_circle", v -> Config.wingsCircle = v))
                        .then(boolOption("wing_particles", v -> Config.wingsParticles = v))
                        .then(doubleOption("wing_scale", 0.5, 2.0, v -> Config.wingsScale = v))
                        // ESP
                        .then(literal("esp_radius").then(argument("value", IntegerArgumentType.integer(16, 500))
                                .executes(c -> {
                                    Config.espRadius = IntegerArgumentType.getInteger(c, "value");
                                    Config.save();
                                    c.getSource().sendFeedback(Text.literal("esp_radius = " + Config.espRadius));
                                    return 1;
                                })))
                        .then(boolOption("esp_players", v -> Config.espPlayers = v))
                        .then(boolOption("esp_chests", v -> Config.espChests = v))
                        .then(boolOption("esp_barrels", v -> Config.espBarrels = v))
                        .then(boolOption("esp_shulkers", v -> Config.espShulkers = v))
                ));
    }
}
