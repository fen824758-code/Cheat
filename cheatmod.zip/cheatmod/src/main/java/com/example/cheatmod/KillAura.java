package com.example.cheatmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class KillAura {
    private static int sinceAttack = 1000;
    private static int sinceAim = 1000;
    private static int aimTicks = 0;
    private static LivingEntity aimTarget = null;

    private KillAura() {}

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (!Config.auraEnabled || player == null || mc.world == null || mc.interactionManager == null
                || !player.isAlive() || player.isSpectator() || mc.currentScreen != null) {
            reset();
            return;
        }

        if (sinceAttack < 10000) sinceAttack++;
        if (sinceAim < 10000) sinceAim++;

        LivingEntity best = findTarget(mc, player);

        // --- Наводка: раз в auraAimInterval секунд, плавный и быстрый доворот ---
        if (Config.auraAim) {
            if (aimTarget == null && best != null && sinceAim >= ticks(Config.auraAimInterval)) {
                aimTarget = best;
                aimTicks = 0;
                sinceAim = 0;
            }
            if (aimTarget != null && !stepAim(player)) {
                aimTarget = null;
            }
        } else {
            aimTarget = null;
        }

        // --- Удар: раз в auraAttackInterval секунд ---
        if (best != null && sinceAttack >= ticks(Config.auraAttackInterval)) {
            mc.interactionManager.attackEntity(player, best);
            player.swingHand(Hand.MAIN_HAND);
            sinceAttack = 0;
        }
    }

    private static void reset() {
        aimTarget = null;
        aimTicks = 0;
        sinceAttack = 1000;
        sinceAim = 1000;
    }

    private static int ticks(double seconds) {
        return Math.max(1, (int) Math.round(seconds * 20.0));
    }

    private static LivingEntity findTarget(MinecraftClient mc, ClientPlayerEntity player) {
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (e == player || !(e instanceof LivingEntity target)) continue;
            if (!target.isAlive() || target instanceof ArmorStandEntity) continue;

            boolean ok;
            if (target instanceof PlayerEntity other) {
                ok = Config.auraPlayers && !other.isSpectator();
            } else {
                ok = Config.auraMobs && target instanceof Monster;
            }
            if (!ok) continue;

            double d = player.distanceTo(target);
            if (d <= Config.auraRange && d < bestDist) {
                bestDist = d;
                best = target;
            }
        }
        return best;
    }

    /** Один тик доворота. Возвращает false, когда наводка закончена. */
    private static boolean stepAim(ClientPlayerEntity p) {
        LivingEntity t = aimTarget;
        if (t == null || !t.isAlive() || t.isRemoved() || p.distanceTo(t) > Config.auraRange + 2.0) {
            return false;
        }

        Vec3d eye = p.getEyePos();
        double dx = t.getX() - eye.x;
        double dy = t.getY() + t.getHeight() * 0.65 - eye.y;
        double dz = t.getZ() - eye.z;

        float wantYaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float wantPitch = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);

        float dYaw = MathHelper.wrapDegrees(wantYaw - p.getYaw());
        float dPitch = wantPitch - p.getPitch();

        p.setYaw(p.getYaw() + step(dYaw));
        p.setPitch(MathHelper.clamp(p.getPitch() + step(dPitch), -90.0f, 90.0f));

        aimTicks++;
        boolean done = Math.abs(dYaw) < 1.0f && Math.abs(dPitch) < 1.0f;
        return !done && aimTicks < 20;
    }

    /** Шаг доворота: пропорционален остатку (плавное торможение), но не медленнее 2.5° и не быстрее 30° за тик. */
    private static float step(float d) {
        float ad = Math.abs(d);
        if (ad <= 1.0f) return d;
        float s = Math.max(2.5f, ad * (float) Config.auraAimSpeed);
        s = Math.min(Math.min(s, 30.0f), ad);
        return Math.copySign(s, d);
    }
}
