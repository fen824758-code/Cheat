package com.example.cheatmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

public final class KillAura {
    private KillAura() {}

    public static void tick(MinecraftClient mc) {
        if (!Config.auraEnabled) return;

        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.interactionManager == null) return;
        if (!player.isAlive() || player.isSpectator() || mc.currentScreen != null) return;

        // Ждём перезарядки удара, чтобы бить на полный урон
        if (player.getAttackCooldownProgress(0.5f) < 0.95f) return;

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (e == player || !(e instanceof LivingEntity target)) continue;
            if (!target.isAlive() || target instanceof ArmorStandEntity) continue;

            boolean ok;
            if (target instanceof PlayerEntity other) {
                ok = Config.auraPlayers && !other.isSpectator();
            } else {
                ok = Config.auraMobs && target instanceof Monster;
            }
            if (!ok) continue;

            double d = player.distanceTo(target);
            if (d <= Config.auraRange && d < bestDist) {
                bestDist = d;
                best = target;
            }
        }

        if (best != null) {
            mc.interactionManager.attackEntity(player, best);
            player.swingHand(Hand.MAIN_HAND);
        }
    }
}
