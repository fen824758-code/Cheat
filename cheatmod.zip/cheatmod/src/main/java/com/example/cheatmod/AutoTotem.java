package com.example.cheatmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Если левая рука пуста (тотем сработал), через totemDelay секунд берёт тотем из инвентаря в левую руку. */
public final class AutoTotem {
    private static int missingTicks = 0;

    private AutoTotem() {}

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.totemEnabled || p == null || mc.world == null || mc.interactionManager == null
                || !p.isAlive() || mc.currentScreen != null) {
            missingTicks = 0;
            return;
        }

        // В левой руке что-то есть — ничего не делаем
        if (!p.getOffHandStack().isEmpty()) {
            missingTicks = 0;
            return;
        }

        if (missingTicks < 1000) missingTicks++;
        int need = Math.max(1, (int) Math.round(Config.totemDelay * 20.0));
        if (missingTicks < need) return;

        int slot = findTotemSlot(p);
        if (slot < 0) return; // тотема нет — ждём, пока появится

        // Кнопка 40 + SWAP = обмен слота с левой рукой
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
        missingTicks = 0;
    }

    /** Возвращает номер слота в окне инвентаря игрока (9..35 — основной, 36..44 — хотбар) или -1. */
    private static int findTotemSlot(ClientPlayerEntity p) {
        for (int i = 9; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return 36 + i;
        }
        return -1;
    }
}
