package com.example.cheatmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Если в левой руке был тотем и она опустела (тотем сработал), через totemDelay секунд
 * берёт новый тотем из инвентаря. Если левая рука пуста намеренно, ничего не делает.
 */
public final class AutoTotem {
    private static int missingTicks = 0;
    private static boolean hadTotem = false;

    private AutoTotem() {}

    private static void reset() {
        missingTicks = 0;
        hadTotem = false;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.totemEnabled || p == null || mc.world == null || mc.interactionManager == null
                || !p.isAlive()) {
            reset();
            return;
        }

        var off = p.getOffHandStack();
        if (!off.isEmpty()) {
            hadTotem = off.isOf(Items.TOTEM_OF_UNDYING);
            missingTicks = 0;
            return;
        }
        if (!hadTotem || mc.currentScreen != null) return;

        if (missingTicks < 1000) missingTicks++;
        int need = Math.max(1, (int) Math.round(Config.totemDelay * 20.0));
        if (missingTicks < need) return;

        int slot = findTotemSlot(p);
        if (slot < 0) return; // тотема нет, ждём

        // Кнопка 40 + SWAP = обмен слота с левой рукой
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
        missingTicks = 0;
    }

    /** Слот в окне инвентаря игрока (9..35 основной, 36..44 хотбар) или -1. */
    private static int findTotemSlot(ClientPlayerEntity p) {
        for (int i = 9; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return 36 + i;
        }
        return -1;
    }
}
