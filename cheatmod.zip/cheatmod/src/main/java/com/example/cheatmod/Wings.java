package com.example.cheatmod;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Фиолетовые крылья за спиной + вращающийся круг под ногами + искры.
 * Рисуется только для локального игрока (то есть для того, кто пользуется модом).
 */
public final class Wings {
    private static final Identifier WINGS = Identifier.of("cheatmod", "textures/effects/wings.png");
    private static final Identifier CIRCLE = Identifier.of("cheatmod", "textures/effects/circle.png");
    private static final Identifier SPARK = Identifier.of("cheatmod", "textures/effects/spark.png");

    // Одно крыло = половина картинки (418x470 px). Размеры в блоках при scale = 1.
    private static final double WING_W = 1.35;
    private static final double WING_H = WING_W * 470.0 / 418.0;

    private static final class Particle {
        double x, y, z, vx, vy, vz;
        int age, life;
        float size;
    }

    private static final Random RNG = new Random();
    private static final List<Particle> PARTICLES = new ArrayList<>();
    private static float phase = 0f;
    private static float rate = 0.10f;
    private static float amp = 9f;
    private static int age = 0;

    private Wings() {}

    // ---------- геометрия ----------

    private static Vec3d fwd(double byRad) {
        return new Vec3d(-Math.sin(byRad), 0, Math.cos(byRad));
    }

    private static Vec3d right(double byRad) {
        return new Vec3d(-Math.cos(byRad), 0, -Math.sin(byRad));
    }

    private static Vec3d hinge(Vec3d feet, Vec3d f, boolean sneaking) {
        double y = sneaking ? 1.0 : 1.28;
        return feet.add(0, y, 0).subtract(f.multiply(0.30));
    }

    /** Угол взмаха (рад): 0 — крыло горизонтально, > 0 — кончик поднят. */
    private static double flap(float ph) {
        return Math.toRadians(14.0 + amp * Math.sin(ph));
    }

    // ---------- тики: анимация и искры ----------

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || !Config.wingsEnabled) {
            PARTICLES.clear();
            return;
        }
        age++;

        Vec3d vel = p.getVelocity();
        double speed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
        boolean air = !p.isOnGround();
        float targetRate = 0.10f + (air ? 0.20f : (float) Math.min(0.12, speed * 0.8));
        float targetAmp = air ? 26f : (float) (9.0 + Math.min(10.0, speed * 40.0));
        rate += (targetRate - rate) * 0.2f;
        amp += (targetAmp - amp) * 0.2f;
        phase += rate;

        Iterator<Particle> it = PARTICLES.iterator();
        while (it.hasNext()) {
            Particle q = it.next();
            if (++q.age >= q.life) {
                it.remove();
                continue;
            }
            q.x += q.vx;
            q.y += q.vy;
            q.z += q.vz;
            q.vx *= 0.97;
            q.vy *= 0.98;
            q.vz *= 0.97;
        }

        if (Config.wingsParticles && !p.isSleeping() && PARTICLES.size() < 200) {
            double byr = Math.toRadians(p.getBodyYaw());
            Vec3d f = fwd(byr);
            Vec3d r = right(byr);
            Vec3d h = hinge(p.getPos(), f, p.isInSneakingPose());
            double s = Config.wingsScale;
            double t = flap(phase);
            for (int i = 0; i < 2; i++) {
                double side = RNG.nextBoolean() ? 1 : -1;
                Vec3d d = r.multiply(side * Math.cos(t)).add(0, Math.sin(t), 0);
                Vec3d u2 = new Vec3d(0, Math.cos(t), 0).subtract(r.multiply(side * Math.sin(t)));
                double dist = (0.3 + RNG.nextDouble()) * WING_W * s;
                double vert = (-0.35 + RNG.nextDouble() * 0.95) * WING_H * s;
                Vec3d pos = h.add(d.multiply(dist)).add(u2.multiply(vert));

                Particle q = new Particle();
                q.x = pos.x;
                q.y = pos.y;
                q.z = pos.z;
                q.vx = (RNG.nextDouble() - 0.5) * 0.02;
                q.vy = 0.005 + RNG.nextDouble() * 0.02;
                q.vz = (RNG.nextDouble() - 0.5) * 0.02;
                q.life = 20 + RNG.nextInt(25);
                q.size = 0.07f + RNG.nextFloat() * 0.12f;
                PARTICLES.add(q);
            }
        }
    }

    // ---------- рендер ----------

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (!Config.wingsEnabled || p == null || mc.world == null || p.isSleeping()) return;

        MatrixStack matrices = ctx.matrixStack();
        if (matrices == null) return;
        Matrix4f m = matrices.peek().getPositionMatrix();

        float td = ctx.tickCounter().getTickDelta(false);
        Vec3d cam = ctx.camera().getPos();
        Vec3d feet = p.getLerpedPos(td);
        double byr = Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
        Vec3d f = fwd(byr);
        Vec3d r = right(byr);
        double s = Config.wingsScale;
        double t = flap(phase + rate * td);
        float pulse = 0.88f + 0.12f * (float) Math.sin((age + td) * 0.12);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

        // 1) Магический круг под ногами (вращается)
        if (Config.wingsCircle) {
            RenderSystem.setShaderTexture(0, CIRCLE);
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            double ang = Math.toRadians((age + td) * 3.0);
            double ca = Math.cos(ang), sa = Math.sin(ang);
            double half = 1.7;
            double y = feet.y + 0.03;
            double[][] c = {{-half, -half}, {half, -half}, {half, half}, {-half, half}};
            float[][] uv = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
            for (int i = 0; i < 4; i++) {
                double x = c[i][0] * ca - c[i][1] * sa;
                double z = c[i][0] * sa + c[i][1] * ca;
                vert(b, m, cam, feet.x + x, y, feet.z + z, uv[i][0], uv[i][1], 1f, 1f, 1f, 0.9f * pulse);
            }
            BufferRenderer.drawWithGlobalProgram(b.end());
            RenderSystem.defaultBlendFunc();
        }

        // 2) Крылья: обычный проход + аддитивное свечение
        Vec3d h = hinge(feet, f, p.isInSneakingPose());
        double w = WING_W * s;
        double hh = WING_H * s;

        RenderSystem.setShaderTexture(0, WINGS);
        BufferBuilder wb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        wing(wb, m, cam, h, r, -1, t, w, hh, 0.0f, 0.5f, pulse, 1.0f);
        wing(wb, m, cam, h, r, 1, t, w, hh, 1.0f, 0.5f, pulse, 1.0f);
        BufferRenderer.drawWithGlobalProgram(wb.end());

        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        BufferBuilder gb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        wing(gb, m, cam, h, r, -1, t, w, hh, 0.0f, 0.5f, pulse, 0.4f);
        wing(gb, m, cam, h, r, 1, t, w, hh, 1.0f, 0.5f, pulse, 0.4f);
        BufferRenderer.drawWithGlobalProgram(gb.end());

        // 3) Искры (всегда повёрнуты к камере)
        if (!PARTICLES.isEmpty()) {
            RenderSystem.setShaderTexture(0, SPARK);
            BufferBuilder pb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            double cy = Math.toRadians(ctx.camera().getYaw());
            double cp = Math.toRadians(ctx.camera().getPitch());
            Vec3d camRight = new Vec3d(-Math.cos(cy), 0, -Math.sin(cy));
            Vec3d camUp = new Vec3d(-Math.sin(cy) * Math.sin(cp), Math.cos(cp), Math.cos(cy) * Math.sin(cp));
            for (Particle q : PARTICLES) {
                float life = 1f - (q.age + td) / q.life;
                double sz = q.size * (0.5 + 0.5 * life);
                float a = Math.min(1f, life * 1.5f);
                Vec3d c = new Vec3d(q.x + q.vx * td, q.y + q.vy * td, q.z + q.vz * td);
                Vec3d rr = camRight.multiply(sz);
                Vec3d uu = camUp.multiply(sz);
                vert(pb, m, cam, c.subtract(rr).add(uu), 0, 0, 0.85f, 0.7f, 1f, a);
                vert(pb, m, cam, c.add(rr).add(uu), 1, 0, 0.85f, 0.7f, 1f, a);
                vert(pb, m, cam, c.add(rr).subtract(uu), 1, 1, 0.85f, 0.7f, 1f, a);
                vert(pb, m, cam, c.subtract(rr).subtract(uu), 0, 1, 0.85f, 0.7f, 1f, a);
            }
            BufferRenderer.drawWithGlobalProgram(pb.end());
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    /** Одно крыло: шарнир у спины, угол t — взмах (поворот вокруг оси «вперёд-назад»). */
    private static void wing(BufferBuilder b, Matrix4f m, Vec3d cam, Vec3d hinge, Vec3d r, double side,
                             double t, double w, double h, float uOuter, float uInner, float pulse, float alpha) {
        Vec3d d = r.multiply(side * Math.cos(t)).add(0, Math.sin(t), 0);
        Vec3d u2 = new Vec3d(0, Math.cos(t), 0).subtract(r.multiply(side * Math.sin(t)));
        double vOff = 0.15 * h; // корень крыла на картинке находится на ~65% высоты

        Vec3d topIn = hinge.add(u2.multiply(0.5 * h + vOff));
        Vec3d botIn = hinge.add(u2.multiply(-0.5 * h + vOff));
        Vec3d topOut = topIn.add(d.multiply(w));
        Vec3d botOut = botIn.add(d.multiply(w));

        float c = pulse;
        vert(b, m, cam, topIn, uInner, 0, c, c, c, alpha);
        vert(b, m, cam, topOut, uOuter, 0, c, c, c, alpha);
        vert(b, m, cam, botOut, uOuter, 1, c, c, c, alpha);
        vert(b, m, cam, botIn, uInner, 1, c, c, c, alpha);
    }

    private static void vert(BufferBuilder b, Matrix4f m, Vec3d cam, Vec3d p, float u, float v,
                             float r, float g, float bl, float a) {
        vert(b, m, cam, p.x, p.y, p.z, u, v, r, g, bl, a);
    }

    private static void vert(BufferBuilder b, Matrix4f m, Vec3d cam, double x, double y, double z,
                             float u, float v, float r, float g, float bl, float a) {
        b.vertex(m, (float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z))
                .texture(u, v)
                .color(r, g, bl, a);
    }
}
