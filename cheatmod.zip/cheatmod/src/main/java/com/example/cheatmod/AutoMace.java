package com.example.cheatmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * AutoMace: ты падаешь на игрока сверху и до него осталось не больше maceHeight блоков.
 * Тогда мод наводится на него, берёт булаву из хотбара и бьёт (smash-атака).
 */
public final class AutoMace {
    private static final double REACH = 3.0;          // макс. дистанция удара
    private static final double HORIZONTAL = 2.5;     // макс. смещение по горизонтали
    private static final int COOLDOWN_TICKS = 12;

    private static int prevSlot = -1;     // слот, который был до смены на булаву
    private static int restoreIn = -1;    // через сколько тиков вернуть слот
    private static int cooldown = 0;

    private AutoMace() {}

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            prevSlot = -1;
            restoreIn = -1;
            return;
        }

        // Возврат на прежний слот после удара
        if (restoreIn >= 0 && --restoreIn < 0 && prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }

        if (cooldown > 0) cooldown--;

        if (!Config.maceEnabled || !p.isAlive() || p.isSpectator() || mc.currentScreen != null) return;
        if (cooldown > 0 || p.isOnGround() || p.isFallFlying() || p.isTouchingWater()) return;
        // Smash-атака работает, только когда падаешь с высоты больше 1.5 блока
        if (p.getVelocity().y >= 0 || p.fallDistance <= 1.5) return;

        int maceSlot = findMaceSlot(p);
        if (maceSlot < 0) return;

        PlayerEntity target = findTarget(mc, p);
        if (target == null) return;

        // Наводка (быстрая и плавная)
        aim(p, target);

        // Берём булаву
        if (p.getInventory().selectedSlot != maceSlot) {
            if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = maceSlot;
        }

        // Бьём
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        cooldown = COOLDOWN_TICKS;
        if (Config.maceSwitchBack && prevSlot >= 0) restoreIn = 2;
    }

    private static int findMaceSlot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.MACE)) return i;
        }
        return -1;
    }

    /** Ближайший игрок, который находится ниже тебя не больше чем на maceHeight блоков. */
    private static PlayerEntity findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == p || !other.isAlive() || other.isSpectator()) continue;

            double dy = p.getY() - other.getY();
            if (dy < 0.3 || dy > Config.maceHeight) continue;

            double dx = other.getX() - p.getX();
            double dz = other.getZ() - p.getZ();
            if (Math.sqrt(dx * dx + dz * dz) > HORIZONTAL) continue;

            double d = p.distanceTo(other);
            if (d > REACH + 0.5) continue;
            if (d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    private static void aim(ClientPlayerEntity p, PlayerEntity t) {
        Vec3d eye = p.getEyePos();
        double dx = t.getX() - eye.x;
        double dy = t.getY() + t.getHeight() * 0.8 - eye.y;
        double dz = t.getZ() - eye.z;

        float wantYaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float wantPitch = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);

        p.setYaw(p.getYaw() + step(MathHelper.wrapDegrees(wantYaw - p.getYaw())));
        p.setPitch(MathHelper.clamp(p.getPitch() + step(wantPitch - p.getPitch()), -90.0f, 90.0f));
    }

    /** Быстрый, но не мгновенный доворот: 70% остатка, минимум 8°, максимум 45° за тик. */
    private static float step(float d) {
        float ad = Math.abs(d);
        if (ad <= 1.0f) return d;
        float s = Math.min(Math.min(Math.max(8.0f, ad * 0.7f), 45.0f), ad);
        return Math.copySign(s, d);
    }
}
