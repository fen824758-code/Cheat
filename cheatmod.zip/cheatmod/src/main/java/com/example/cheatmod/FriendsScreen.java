package com.example.cheatmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Меню друзей (клавиша Z): добавить / убрать друга и задать тег (до 10 символов) для таба. */
public class FriendsScreen extends Screen {
    private static final int ROWS = 7;

    private TextFieldWidget nickField;
    private TextFieldWidget tagField;
    private String nickText = "";
    private String tagText = "";
    private String error = "";
    private int scroll = 0;
    private List<Map.Entry<String, String>> shown = new ArrayList<>();

    public FriendsScreen() {
        super(Text.literal("Друзья"));
    }

    private int top() {
        return height / 2 - 95;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int top = top();

        nickField = new TextFieldWidget(textRenderer, cx - 150, top + 22, 110, 20, Text.literal("Ник"));
        nickField.setMaxLength(16);
        nickField.setText(nickText);
        nickField.setSuggestion(nickText.isEmpty() ? "ник" : null);
        nickField.setChangedListener(t -> {
            nickText = t;
            nickField.setSuggestion(t.isEmpty() ? "ник" : null);
        });
        addDrawableChild(nickField);

        tagField = new TextFieldWidget(textRenderer, cx - 35, top + 22, 90, 20, Text.literal("Тег"));
        tagField.setMaxLength(Config.TAG_MAX);
        tagField.setText(tagText);
        tagField.setSuggestion(tagText.isEmpty() ? "тег" : null);
        tagField.setChangedListener(t -> {
            tagText = t;
            tagField.setSuggestion(t.isEmpty() ? "тег" : null);
        });
        addDrawableChild(tagField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Добавить"), b -> addCurrent())
                .dimensions(cx + 60, top + 22, 90, 20).build());

        shown = new ArrayList<>(Config.friends.entrySet());
        scroll = Math.max(0, Math.min(scroll, Math.max(0, shown.size() - ROWS)));
        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx >= shown.size()) break;
            String nick = shown.get(idx).getKey();
            addDrawableChild(ButtonWidget.builder(Text.literal("Убрать"), b -> {
                Config.removeFriend(nick);
                clearAndInit();
            }).dimensions(cx + 90, top + 56 + i * 22, 60, 20).build());
        }

        setInitialFocus(nickField);
    }

    private void addCurrent() {
        String nick = nickText.trim();
        if (!nick.matches("[A-Za-z0-9_.]{1,16}")) {
            error = "Ник: до 16 символов, латиница, цифры, _ и .";
            return;
        }
        Config.addFriend(nick, tagText);
        nickText = "";
        tagText = "";
        error = "";
        clearAndInit();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            addCurrent();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, Config.friends.size() - ROWS);
        int ns = Math.max(0, Math.min(max, scroll - (int) Math.signum(verticalAmount)));
        if (ns != scroll) {
            scroll = ns;
            clearAndInit();
        }
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = width / 2;
        int top = top();

        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Друзья"), cx, top, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Ник"), cx - 150, top + 12, 0xAAAAAA);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Тег (до " + Config.TAG_MAX + ")"), cx - 35, top + 12, 0xAAAAAA);

        if (!error.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, Text.literal(error), cx - 150, top + 46, 0xFF5555);
        }

        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx >= shown.size()) break;
            Map.Entry<String, String> e = shown.get(idx);
            String tag = e.getValue();
            String line = e.getKey() + (tag.isEmpty() ? "" : "  [" + tag + "]");
            ctx.drawTextWithShadow(textRenderer, Text.literal(line), cx - 150, top + 62 + i * 22, 0x55FF55);
        }

        if (shown.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Список пуст"), cx, top + 80, 0x888888);
        }
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Enter - добавить · колесо - прокрутка · Esc - закрыть"), cx, top + 56 + ROWS * 22 + 8, 0x888888);
    }
}
