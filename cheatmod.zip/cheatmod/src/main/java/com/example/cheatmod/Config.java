package com.example.cheatmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Простой JSON-конфиг: .minecraft/config/cheatmod.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cheatmod.json");

    // Kill aura
    public static boolean auraEnabled = false;
    public static double auraRange = 4.2;      // 1.0 .. 6.0
    public static boolean auraPlayers = true;
    public static boolean auraMobs = true;

    // ESP
    public static boolean espEnabled = false;
    public static int espRadius = 500;         // 16 .. 500
    public static boolean espPlayers = true;
    public static boolean espChests = true;
    public static boolean espBarrels = true;

    private Config() {}

    public static void load() {
        try {
            if (!Files.exists(FILE)) {
                save();
                return;
            }
            JsonObject o = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (o == null) return;
            auraEnabled = bool(o, "auraEnabled", auraEnabled);
            auraRange = Math.max(1.0, Math.min(6.0, num(o, "auraRange", auraRange)));
            auraPlayers = bool(o, "auraPlayers", auraPlayers);
            auraMobs = bool(o, "auraMobs", auraMobs);
            espEnabled = bool(o, "espEnabled", espEnabled);
            espRadius = (int) Math.max(16, Math.min(500, num(o, "espRadius", espRadius)));
            espPlayers = bool(o, "espPlayers", espPlayers);
            espChests = bool(o, "espChests", espChests);
            espBarrels = bool(o, "espBarrels", espBarrels);
        } catch (Exception e) {
            System.err.println("[CheatMod] Не удалось прочитать конфиг: " + e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("auraEnabled", auraEnabled);
            o.addProperty("auraRange", auraRange);
            o.addProperty("auraPlayers", auraPlayers);
            o.addProperty("auraMobs", auraMobs);
            o.addProperty("espEnabled", espEnabled);
            o.addProperty("espRadius", espRadius);
            o.addProperty("espPlayers", espPlayers);
            o.addProperty("espChests", espChests);
            o.addProperty("espBarrels", espBarrels);
            Files.writeString(FILE, GSON.toJson(o));
        } catch (Exception e) {
            System.err.println("[CheatMod] Не удалось сохранить конфиг: " + e);
        }
    }

    private static boolean bool(JsonObject o, String k, boolean def) {
        return o.has(k) ? o.get(k).getAsBoolean() : def;
    }

    private static double num(JsonObject o, String k, double def) {
        return o.has(k) ? o.get(k).getAsDouble() : def;
    }
}
