package com.example.cheatmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Простой JSON-конфиг: .minecraft/config/cheatmod.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cheatmod.json");

    // Kill aura
    public static boolean auraEnabled = false;
    public static double auraRange = 4.2;      // 1.0 .. 6.0
    public static boolean auraPlayers = true;
    public static boolean auraMobs = true;
    public static double auraAttackInterval = 1.0; // секунд между ударами (0.1 .. 5)
    public static boolean auraAim = true;          // плавная наводка
    public static double auraAimInterval = 1.0;    // секунд между наводками (0.2 .. 10)
    public static double auraAimSpeed = 0.4;       // 0.1 (плавнее) .. 1.0 (резче)

    // Auto totem
    public static boolean totemEnabled = false;
    public static double totemDelay = 1.0;         // секунд до взятия тотема (0 .. 5)

    // Night vision
    public static boolean nightVisionEnabled = false;

    // Auto mace
    public static boolean maceEnabled = false;
    public static double maceHeight = 2.0;         // макс. высота над целью, блоков (1 .. 4)
    public static boolean maceSwitchBack = true;   // вернуть прежний слот после удара

    // Auto crystal
    public static boolean crystalEnabled = false;
    public static double crystalRange = 4.5;        // дальность установки/удара (1 .. 6)
    public static double crystalMinSelf = 3.0;      // не ставить/бить кристаллы ближе к себе (1 .. 8)
    public static double crystalMinHealth = 6.0;    // при таком здоровье и ниже не работает (0 .. 20)
    public static boolean crystalSwitch = true;     // брать кристаллы из хотбара
    public static double crystalPlaceDelay = 0.1;   // секунд между установками (0.05 .. 1)
    public static double crystalBreakDelay = 0.05;  // секунд между ударами (0.05 .. 1)

    // ESP
    public static boolean espEnabled = false;
    public static int espRadius = 500;         // 16 .. 500
    public static boolean espPlayers = true;
    public static boolean espChests = true;
    public static boolean espBarrels = true;
    public static boolean espShulkers = true;


    private Config() {}

    public static void load() {
        try {
            if (!Files.exists(FILE)) {
                save();
                return;
            }
            JsonObject o = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (o == null) return;
            auraEnabled = bool(o, "auraEnabled", auraEnabled);
            auraRange = Math.max(1.0, Math.min(6.0, num(o, "auraRange", auraRange)));
            auraPlayers = bool(o, "auraPlayers", auraPlayers);
            auraMobs = bool(o, "auraMobs", auraMobs);
            auraAttackInterval = Math.max(0.1, Math.min(5.0, num(o, "auraAttackInterval", auraAttackInterval)));
            auraAim = bool(o, "auraAim", auraAim);
            auraAimInterval = Math.max(0.2, Math.min(10.0, num(o, "auraAimInterval", auraAimInterval)));
            auraAimSpeed = Math.max(0.1, Math.min(1.0, num(o, "auraAimSpeed", auraAimSpeed)));
            totemEnabled = bool(o, "totemEnabled", totemEnabled);
            totemDelay = Math.max(0.0, Math.min(5.0, num(o, "totemDelay", totemDelay)));
            nightVisionEnabled = bool(o, "nightVisionEnabled", nightVisionEnabled);
            maceEnabled = bool(o, "maceEnabled", maceEnabled);
            maceHeight = Math.max(1.0, Math.min(4.0, num(o, "maceHeight", maceHeight)));
            maceSwitchBack = bool(o, "maceSwitchBack", maceSwitchBack);
            crystalEnabled = bool(o, "crystalEnabled", crystalEnabled);
            crystalRange = Math.max(1.0, Math.min(6.0, num(o, "crystalRange", crystalRange)));
            crystalMinSelf = Math.max(1.0, Math.min(8.0, num(o, "crystalMinSelf", crystalMinSelf)));
            crystalMinHealth = Math.max(0.0, Math.min(20.0, num(o, "crystalMinHealth", crystalMinHealth)));
            crystalSwitch = bool(o, "crystalSwitch", crystalSwitch);
            crystalPlaceDelay = Math.max(0.05, Math.min(1.0, num(o, "crystalPlaceDelay", crystalPlaceDelay)));
            crystalBreakDelay = Math.max(0.05, Math.min(1.0, num(o, "crystalBreakDelay", crystalBreakDelay)));
            espEnabled = bool(o, "espEnabled", espEnabled);
            espRadius = (int) Math.max(16, Math.min(500, num(o, "espRadius", espRadius)));
            espPlayers = bool(o, "espPlayers", espPlayers);
            espChests = bool(o, "espChests", espChests);
            espBarrels = bool(o, "espBarrels", espBarrels);
            espShulkers = bool(o, "espShulkers", espShulkers);
        } catch (Exception e) {
            System.err.println("[CheatMod] Не удалось прочитать конфиг: " + e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("auraEnabled", auraEnabled);
            o.addProperty("auraRange", auraRange);
            o.addProperty("auraPlayers", auraPlayers);
            o.addProperty("auraMobs", auraMobs);
            o.addProperty("auraAttackInterval", auraAttackInterval);
            o.addProperty("auraAim", auraAim);
            o.addProperty("auraAimInterval", auraAimInterval);
            o.addProperty("auraAimSpeed", auraAimSpeed);
            o.addProperty("totemEnabled", totemEnabled);
            o.addProperty("totemDelay", totemDelay);
            o.addProperty("nightVisionEnabled", nightVisionEnabled);
            o.addProperty("maceEnabled", maceEnabled);
            o.addProperty("maceHeight", maceHeight);
            o.addProperty("maceSwitchBack", maceSwitchBack);
            o.addProperty("crystalEnabled", crystalEnabled);
            o.addProperty("crystalRange", crystalRange);
            o.addProperty("crystalMinSelf", crystalMinSelf);
            o.addProperty("crystalMinHealth", crystalMinHealth);
            o.addProperty("crystalSwitch", crystalSwitch);
            o.addProperty("crystalPlaceDelay", crystalPlaceDelay);
            o.addProperty("crystalBreakDelay", crystalBreakDelay);
            o.addProperty("espEnabled", espEnabled);
            o.addProperty("espRadius", espRadius);
            o.addProperty("espPlayers", espPlayers);
            o.addProperty("espChests", espChests);
            o.addProperty("espBarrels", espBarrels);
            o.addProperty("espShulkers", espShulkers);
            Files.writeString(FILE, GSON.toJson(o));
        } catch (Exception e) {
            System.err.println("[CheatMod] Не удалось сохранить конфиг: " + e);
        }
    }

    private static boolean bool(JsonObject o, String k, boolean def) {
        return o.has(k) ? o.get(k).getAsBoolean() : def;
    }

    private static double num(JsonObject o, String k, double def) {
        return o.has(k) ? o.get(k).getAsDouble() : def;
    }
}
