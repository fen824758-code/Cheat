package com.example.cheatmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** Простой JSON-конфиг: .minecraft/config/cheatmod.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cheatmod.json");

    /** Ванильный сервер 1.21.4 принимает удар примерно до 4 блоков. */
    public static final double MAX_AURA_RANGE = 4.0;

    // Kill aura
    public static boolean auraEnabled = false;
    public static double auraRange = 3.0;          // 1.0 .. 4.0
    public static boolean auraPlayers = true;
    public static boolean auraMobs = true;
    public static boolean auraWalls = false;       // бить сквозь стены
    public static boolean auraCooldown = true;     // ждать полного кулдауна оружия
    public static double auraAttackInterval = 0.5; // минимум секунд между ударами (0.1 .. 5)
    public static boolean auraAim = true;
    public static double auraAimInterval = 1.0;    // 0.2 .. 10
    public static double auraAimSpeed = 0.4;       // 0.1 .. 1.0
    public static final int TAG_MAX = 10;
    /** ник (нижний регистр) -> тег, который показывается в табе (до 10 символов, может быть пустым) */
    public static final Map<String, String> friends = new TreeMap<>();

    // Auto totem
    public static boolean totemEnabled = false;
    public static double totemDelay = 1.0;         // 0 .. 5

    // Night vision
    public static boolean nightVisionEnabled = false;

    // Wings
    public static boolean wingsEnabled = false;
    public static double wingsScale = 1.0;         // 0.5 .. 2.0
    public static boolean wingsCircle = true;
    public static boolean wingsParticles = true;

    // ESP
    public static boolean espEnabled = false;
    public static int espRadius = 500;             // 16 .. 500
    public static boolean espPlayers = true;
    public static boolean espChests = true;
    public static boolean espBarrels = true;
    public static boolean espShulkers = true;

    private Config() {}

    public static String norm(String nick) {
        return nick.toLowerCase(Locale.ROOT);
    }

    public static String cleanTag(String t) {
        if (t == null) return "";
        t = t.replace("§", "").trim();
        return t.length() > TAG_MAX ? t.substring(0, TAG_MAX) : t;
    }

    public static boolean isFriend(String nick) {
        return friends.containsKey(norm(nick));
    }

    /** Тег друга или null, если это не друг. */
    public static String tagOf(String nick) {
        return friends.get(norm(nick));
    }

    public static void addFriend(String nick, String tag) {
        friends.put(norm(nick), cleanTag(tag));
        save();
    }

    public static boolean removeFriend(String nick) {
        boolean r = friends.remove(norm(nick)) != null;
        save();
        return r;
    }

    public static void load() {
        try {
            if (!Files.exists(FILE)) {
                save();
                return;
            }
            JsonObject o = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (o == null) return;
            auraEnabled = bool(o, "auraEnabled", auraEnabled);
            auraRange = clamp(num(o, "auraRange", auraRange), 1.0, MAX_AURA_RANGE);
            auraPlayers = bool(o, "auraPlayers", auraPlayers);
            auraMobs = bool(o, "auraMobs", auraMobs);
            auraWalls = bool(o, "auraWalls", auraWalls);
            auraCooldown = bool(o, "auraCooldown", auraCooldown);
            auraAttackInterval = clamp(num(o, "auraAttackInterval", auraAttackInterval), 0.1, 5.0);
            auraAim = bool(o, "auraAim", auraAim);
            auraAimInterval = clamp(num(o, "auraAimInterval", auraAimInterval), 0.2, 10.0);
            auraAimSpeed = clamp(num(o, "auraAimSpeed", auraAimSpeed), 0.1, 1.0);
            friends.clear();
            if (o.has("friends")) {
                JsonElement fe = o.get("friends");
                if (fe.isJsonObject()) {
                    for (Map.Entry<String, JsonElement> en : fe.getAsJsonObject().entrySet()) {
                        friends.put(norm(en.getKey()), cleanTag(en.getValue().getAsString()));
                    }
                } else if (fe.isJsonArray()) { // старый формат: просто список ников
                    for (JsonElement e : fe.getAsJsonArray()) friends.put(norm(e.getAsString()), "");
                }
            }
            totemEnabled = bool(o, "totemEnabled", totemEnabled);
            totemDelay = clamp(num(o, "totemDelay", totemDelay), 0.0, 5.0);
            nightVisionEnabled = bool(o, "nightVisionEnabled", nightVisionEnabled);
            wingsEnabled = bool(o, "wingsEnabled", wingsEnabled);
            wingsScale = clamp(num(o, "wingsScale", wingsScale), 0.5, 2.0);
            wingsCircle = bool(o, "wingsCircle", wingsCircle);
            wingsParticles = bool(o, "wingsParticles", wingsParticles);
            espEnabled = bool(o, "espEnabled", espEnabled);
            espRadius = (int) clamp(num(o, "espRadius", espRadius), 16, 500);
            espPlayers = bool(o, "espPlayers", espPlayers);
            espChests = bool(o, "espChests", espChests);
            espBarrels = bool(o, "espBarrels", espBarrels);
            espShulkers = bool(o, "espShulkers", espShulkers);
        } catch (Exception e) {
            System.err.println("[CheatMod] Не удалось прочитать конфиг: " + e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("auraEnabled", auraEnabled);
            o.addProperty("auraRange", auraRange);
            o.addProperty("auraPlayers", auraPlayers);
            o.addProperty("auraMobs", auraMobs);
            o.addProperty("auraWalls", auraWalls);
            o.addProperty("auraCooldown", auraCooldown);
            o.addProperty("auraAttackInterval", auraAttackInterval);
            o.addProperty("auraAim", auraAim);
            o.addProperty("auraAimInterval", auraAimInterval);
            o.addProperty("auraAimSpeed", auraAimSpeed);
            JsonObject fr = new JsonObject();
            for (Map.Entry<String, String> f : friends.entrySet()) fr.addProperty(f.getKey(), f.getValue());
            o.add("friends", fr);
            o.addProperty("totemEnabled", totemEnabled);
            o.addProperty("totemDelay", totemDelay);
            o.addProperty("nightVisionEnabled", nightVisionEnabled);
            o.addProperty("wingsEnabled", wingsEnabled);
            o.addProperty("wingsScale", wingsScale);
            o.addProperty("wingsCircle", wingsCircle);
            o.addProperty("wingsParticles", wingsParticles);
            o.addProperty("espEnabled", espEnabled);
            o.addProperty("espRadius", espRadius);
            o.addProperty("espPlayers", espPlayers);
            o.addProperty("espChests", espChests);
            o.addProperty("espBarrels", espBarrels);
            o.addProperty("espShulkers", espShulkers);
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(o));
        } catch (Exception e) {
            System.err.println("[CheatMod] Не удалось сохранить конфиг: " + e);
        }
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static boolean bool(JsonObject o, String k, boolean def) {
        return o.has(k) ? o.get(k).getAsBoolean() : def;
    }

    private static double num(JsonObject o, String k, double def) {
        return o.has(k) ? o.get(k).getAsDouble() : def;
    }
}
