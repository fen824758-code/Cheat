# CheatMod (Fabric 1.21 / 1.21.1)

Клиентский мод: KillAura, ESP (игроки, сундуки, бочки, шалкеры), AutoTotem, ночное зрение. Только для одиночной игры и своих серверов.

## Сборка
1. Создай репозиторий на GitHub, залей содержимое этой папки (корень репозитория = папка с `build.gradle`).
2. Вкладка **Actions** -> workflow `build` -> когда закончится, скачай артефакт `cheatmod` (jar).
3. Положи jar в `.minecraft/mods` вместе с Fabric Loader 0.16.10+ и Fabric API 0.116.6+1.21.1 (работает и на 1.21).

## Управление
- `R` — KillAura вкл/выкл
- `X` — меню чита (клики по переключателям; повторное `X` или `Esc` закрывает)
- `C` — AutoCrystal (ставит кристаллы на обсидиан/бедрок у ближайшего игрока и разбивает их)
- `M` — AutoMace (падаешь на игрока сверху с высоты до 2 блоков: наводка, булава из хотбара, удар)
- `G` — ESP, `V` — AutoTotem, `N` — ночное зрение (клавиши меняются в настройках управления)
- Команды: `/cheat status`, `/cheat aura_range <1-6>`, `/cheat aura_interval|aim_interval|aim_speed|totem_delay|esp_radius <число>`,
  `/cheat aim|aura_players|aura_mobs|esp_players|esp_chests|esp_barrels|esp_shulkers|totem|nightvision <true|false>`
- Конфиг: `.minecraft/config/cheatmod.json`

## Ограничения
- Сундуки и бочки в ESP видны только в загруженных чанках (дальность прорисовки), даже если радиус стоит 500.
- Дальность kill aura ограничена 6 блоками: дальше сервер удар не примет.
