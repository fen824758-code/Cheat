# CheatMod (Fabric 1.21.4)

Клиентский мод: KillAura, ESP, AutoTotem, NightVision, Wings.
**Только для одиночной игры и своих серверов**, где читы разрешены. На публичных серверах такие функции запрещены правилами.

## Сборка
1. Создай репозиторий на GitHub, залей содержимое этой папки (корень репозитория = папка с `build.gradle`).
2. Вкладка **Actions** → workflow `build` → скачай артефакт `cheatmod` (jar).
3. Положи jar в `.minecraft/mods` вместе с Fabric Loader 0.16.10+ и Fabric API 0.119.2+1.21.4.

## Клавиши (меняются в настройках управления)
`R` KillAura · `G` ESP · `V` AutoTotem · `N` NightVision · `X` Wings · `Z` меню друзей

## Меню друзей (Z)
Впиши ник и тег (до 10 символов), нажми «Добавить» или Enter. Повторное добавление того же ника меняет тег.
«Убрать» удаляет друга. Друзья не атакуются KillAura, а тег показывается в табе перед ником: `[тег] ник`.

## Команды `/cheat ...`
- `status`
- KillAura: `aura_range <1-4>`, `aura_interval <0.1-5>`, `aura_players|aura_mobs|aura_walls|aura_cooldown <bool>`,
  `aim <bool>`, `aim_interval`, `aim_speed`, `friend add <ник> [тег]`, `friend remove <ник>`, `friend list`
- ESP: `esp_radius <16-500>`, `esp_players|esp_chests|esp_barrels|esp_shulkers <bool>`
- `totem <bool>`, `totem_delay <0-5>`, `nightvision <bool>`
- Wings: `wings`, `wing_circle`, `wing_particles <bool>`, `wing_scale <0.5-2>`

Конфиг: `.minecraft/config/cheatmod.json`

## Заметки
- Дальность KillAura ограничена 4 блоками: ванильный сервер 1.21.4 дальше удар не принимает.
- По умолчанию аура ждёт полного кулдауна оружия и не бьёт сквозь стены (`aura_cooldown`, `aura_walls`).
- Друзья из списка не атакуются.
- Сундуки, бочки и шалкеры видны только в загруженных чанках (дальность прорисовки).
- AutoTotem срабатывает, только если в левой руке был тотем и пропал.
