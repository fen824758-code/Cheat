# CheatMod (Fabric 1.21.4)

Клиентский мод: KillAura + ESP (игроки, сундуки, бочки). Только для одиночной игры и своих серверов.

## Сборка
1. Создай репозиторий на GitHub, залей содержимое этой папки (корень репозитория = папка с `build.gradle`).
2. Вкладка **Actions** -> workflow `build` -> когда закончится, скачай артефакт `cheatmod` (jar).
3. Положи jar в `.minecraft/mods` вместе с Fabric Loader 0.16.10+ и Fabric API 0.119.2+1.21.4.

## Управление
- `R` — KillAura вкл/выкл
- `G` — ESP вкл/выкл (клавиши меняются в настройках управления)
- Команды: `/cheat status`, `/cheat aura_range <1-6>`, `/cheat esp_radius <16-500>`,
  `/cheat aura_players|aura_mobs|esp_players|esp_chests|esp_barrels <true|false>`
- Конфиг: `.minecraft/config/cheatmod.json`

## Ограничения
- Сундуки и бочки видны только в загруженных чанках (дальность прорисовки), даже если радиус стоит 500.
- Дальность kill aura ограничена 6 блоками: дальше сервер удар не примет.
